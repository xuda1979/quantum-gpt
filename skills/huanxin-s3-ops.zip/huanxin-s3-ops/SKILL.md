---
name: huanxin-s3-ops
description: Operate Huanxin train-dev environments from a local repo and move files between local disk, S3, and Huanxin using repo-local browser automation and shell helpers. Use when the user asks to access Huanxin, run commands on ai1 or ai2, inspect Huanxin auth or daemon state, or sync code and results through S3.
---

# Huanxin + S3 Ops

Use this skill when a workspace already contains repo-local Huanxin and S3 helpers under `scripts/`, `browser-automation/`, and `TOOLS.md`.

This skill is meant to be shareable. Keep environment-specific values out of the skill body:

- canonical Huanxin URL
- S3 bucket or prefix
- remote roots
- preferred env (`ai1` vs `ai2`)
- browser profile paths
- daemon ports

Put those values in `TOOLS.md` or the repo-local helper scripts. Read [references/portability.md](references/portability.md) when adapting this skill to another workspace.

## Sharing This Skill

- Share the `skills/huanxin-s3-ops/` folder.
- The receiving workspace must define its real Huanxin URL, S3 root, remote paths, env defaults, and wrapper script names in `TOOLS.md` or repo-local helper scripts.
- Do not bake personal auth state, cookies, browser profiles, or private bucket details into this skill.

## Core Rules

- Read `TOOLS.md` first for the workspace-specific Huanxin URL, env naming, remote roots, and S3 root.
- Treat Huanxin browser automation as the control plane and S3 as the data plane.
- For file movement, prefer the repo's sync helpers over manual `rclone` or browser paste.
- Validate locally before any remote mutation.
- Use `--dry-run` first for large or risky transfers.
- Do not kill the browser daemon, discard the authenticated profile, or delete remote content unless explicitly instructed.

## Default Workflow

1. Inspect local notes and helper scripts:
   - `TOOLS.md`
   - `scripts/*huanxin*`
   - `scripts/*s3*`
   - `browser-automation/*`
2. Check Huanxin control-plane health:
   - repo status helper if present
   - auth probe only when needed
3. Run remote commands through the shell wrapper:
   - `scripts/huanxin_shell.sh <ai1|ai2> "<cmd>"`
4. Move files through S3:
   - local -> S3
   - S3 -> Huanxin
   - Huanxin -> S3
   - S3 -> local
5. Verify the result with concrete command output, logs, or fetched artifacts.

## Preferred Entry Points

Use the workspace wrappers before lower-level tools:

- Generic shell: `scripts/huanxin_shell.sh <ai1|ai2> "<cmd>"`
- Env shortcuts when present: `scripts/ai1_shell.sh`, `scripts/ai2_shell.sh`
- Local -> S3: `scripts/push_to_s3.sh`
- S3 -> local: `scripts/pull_from_s3.sh`
- S3 -> Huanxin: `scripts/ai1_sync_from_s3.sh`, `scripts/ai2_sync_from_s3.sh`
- Huanxin -> S3: `scripts/ai1_push_results_to_s3.sh`, `scripts/ai2_push_results_to_s3.sh`
- Status and repair helpers when present: `scripts/huanxin_status.sh`, `scripts/repair_huanxin_browser_profile.sh`

Only drop to raw `node browser-automation/huanxin_shell_exec.js ...` or raw `rclone` when the wrappers are missing or clearly insufficient.

## Choosing The Environment

- Prefer the workspace default env from `TOOLS.md`.
- If the workspace allows both `ai1` and `ai2`, use the one that best matches capacity, isolation, or current assignment.
- Do not assume `ai1` and `ai2` share the same remote root. Read the helper script defaults or `TOOLS.md`.

## When To Load References

- Read [references/workflows.md](references/workflows.md) for concrete command recipes.
- Read [references/portability.md](references/portability.md) when packaging or adapting the skill for another repo.

## Success Standard

A successful step should leave at least one concrete artifact:

- shell JSON output
- sync log tail
- remote file listing
- fetched result file
- updated local note describing the exact state reached
